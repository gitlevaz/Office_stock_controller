<!DOCTYPE html>
<html>
<head>
	<title></title>
<style type="text/css">
	.invoice_headtxt{
		text-align: center;
	}
</style>
</head>
<body>
<div class="invoice_print">
	<h3 class="invoice_headtxt">Invoice</h3>
</div>
<?php
$a=$_GET['stat'];
echo $a;
	
?>
</body>
<script>

</script>
</html>