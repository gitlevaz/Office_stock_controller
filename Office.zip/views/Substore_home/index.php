<div class="row">
	<div class="col-sm-2 col-md-2">
	<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Inventory_home" class='backButton'><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div></div>
		<?php
		//include 'views/common/Inventory_home.php';
		?>	
	</div>
	<div class="col-sm-8 col-md-8">
		<div class="row">
			<ul class="center_menu">
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Substore_create"><i class="fa fa-shopping-bag" aria-hidden="true" style="margin-right:2%"></i>Add Sub Store</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Substore_issuenote"><i class="fa fa-sticky-note" aria-hidden="true" style="margin-right:2%"></i>Issue Note</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Substore_returns"><i class="fa fa-reply" aria-hidden="true" style="margin-right:2%"></i>Returns</a></li>

			</ul>
		</div>
	</div>
</div>
