<div class="row">
<div class="col-sm-2 col-md-2">
	<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Store_home" class="backButton"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div></div>
	<?php
	include 'views/common/purchaseorders_left.php';
	?>	
</div>
<div class="col-sm-10 col-md-10">
	  <div class="row datalist">
		  <div class="col-md-12 col-sm-12">
			  <div class="panel panel-default">
			    <!-- Default panel contents -->
			    <div class="panel-heading">

			  </div>
			  <div class="row">
			    <div class="col-sm-12 col-md-12">
			    	<input type="hidden" id="new_count" value="0">
				    <div class="edit_animation"></div>

			        <div class="pagin">
			        	
			        </div>
			    </div>
			  </div>
			  </div>
		   </div>
	  </div>
</div>
</div>
<script type="text/javascript">
</script>