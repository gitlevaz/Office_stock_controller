<div class="row">
	<div class="col-sm-2 col-md-2">
	<div class="row"><a href="<?php ROOT?>Inventory_home" class="backButton"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div>
		<?php
		//include 'views/common/Inventory_home.php';
		?>	
	</div>
	<div class="col-sm-10 col-md-10">
		<div class="row">
			<ul class="center_menu center_Inventory_home">
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Stockitmes_home"><i class="fa fa-archive aria-hidden="true" style="margin-right:2%"></i> Stock Itmes</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Itemcategory_home"><i class="fa fa-medkit" aria-hidden="true" style="margin-right:2%"></i>Item categorys</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Grn_home"><i class="fa fa-file-text-o" aria-hidden="true" style="margin-right:2%"></i>Grn</a></li>
			    <li class="thumbnail moduleBg"><a href=""><i class="fa fa-shopping-cart aria-hidden="true" style="margin-right:2%"></i>Purchase Orders</a></li>
			    <!-- <li class="thumbnail moduleBg"><a href="<?php ROOT?>purchaseorders_home"><i class="fa fa-shopping-cart aria-hidden="true" style="margin-right:2%"></i>Purchase Orders</a></li> -->
			    <!-- <li class="thumbnail moduleBg"><a href="<?php ROOT?>purchaseorders_requested"><i class="fa fa-cart-plus aria-hidden="true" style="margin-right:2%"></i> Requested Purchase Orders</a></li> -->
			    <li class="thumbnail moduleBg"><a href=""><i class="fa fa-cart-plus aria-hidden="true" style="margin-right:2%"></i> Requested Purchase Orders</a></li>
			</ul>
		</div>
	</div>
</div>
