<div class="row">
	<div class="col-sm-2 col-md-2">
	<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Store_home" class="backButton"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div></div>
		<?php
		//include 'views/common/Inventory_home.php';
		?>	
	</div>
	<div class="col-sm-10 col-md-10">
		<div class="row">
			<ul class="center_menu center_Inventory_home">
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Itemcategory_category"><i class="fa fa-medkit" aria-hidden="true" style="margin-right:2%"></i> Item Category</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Itemcategory_subcategory"><i class="fa fa-suitcase" aria-hidden="true" style="margin-right:2%"></i>Sub Category</a></li>
			</ul>
		</div>
	</div>
</div>
