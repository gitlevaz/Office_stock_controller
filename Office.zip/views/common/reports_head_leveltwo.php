<div class="col-sm-12 col-md-12">
	<input type="text" placeholder="form" class="datepicker date_from"><input type="text" placeholder="to" class="datepicker date_to"><input type="Button" class="search_btn" value="Search">
	<label><div id="msg_box"></div></label>	
</div>
