<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Prescription_home" class="btn btn-link addnewButton"><i class="fa fa-newspaper-o" aria-hidden="true" style="margin-right:2%; transform: rotate(90deg);"></i>New Invoice </a></li>
   		<li><a href="<?php ROOT?>Prescription_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%;"></i>Edit Invoice</a></li>
   		   		<li><a href="<?php ROOT?>Prescription_view" class="btn btn-link addnewButton"><i class="" aria-hidden="true" style="margin-right:2%;"></i>View Prescriptions</a></li>
   </ul>
</div>