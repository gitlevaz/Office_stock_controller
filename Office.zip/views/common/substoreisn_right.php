<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Substore_issuenote" class="btn btn-link addnewButton"><i class="fa fa-sticky-note" aria-hidden="true" style="margin-right:2%"></i>New issue note</a></li>
   		<li><a href="<?php ROOT?>Substore_issuenoteedit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit issue note</a></li>
   </ul>
</div>