<div>
   <ul  class="ulHope">
   		<li><a href="<?php ROOT?>Invoice_return" class="btn btn-link addnewButton">New Return Note</a></li>
   		<li><a href="<?php ROOT?>Invoice_returnedit" class="btn btn-link addnewButton">Edit Return Note</a></li>
   </ul>
</div>