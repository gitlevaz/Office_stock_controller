<div>
   <ul class="ulHope">
   		<li class=""><a href="<?php ROOT?>Employee_home" class="btn btn-link addnewButton" ><i class="fa fa-user-plus" aria-hidden="true" style="margin-right:1%"></i>New Employee</a></li>
   		<li class=""><a href="<?php ROOT?>Employee_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Employee</a></li>
   </ul>
</div>