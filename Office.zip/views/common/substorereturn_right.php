<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Substore_returns" class="btn btn-link addnewButton"><i class="fa fa-reply" aria-hidden="true" style="margin-right:2%"></i>New return note</a></li>
   		<li><a href="<?php ROOT?>Substore_returnsedit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit return note</a></li>
   </ul>
</div>