<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>purchaseorders_home" class="btn btn-link addnewButton"><i class="fa fa-newspaper-o" aria-hidden="true" style="margin-right:2%; transform: rotate(90deg);"></i>New Order</a></li>
   		<li><a href="<?php ROOT?>purchaseorders_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%;"></i>Edit Order</a></li>
   		<li><a href="<?php ROOT?>purchaseorders_status" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%;"></i>Order Status</a></li>
   		
   </ul>
</div>