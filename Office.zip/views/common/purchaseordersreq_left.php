<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>purchaseorders_requested" class="btn btn-link addnewButton"><i class="fa fa-newspaper-o" aria-hidden="true" style="margin-right:2%; transform: rotate(90deg);"></i>Requested Ordes</a></li>
   		<li><a href="<?php ROOT?>purchaseorders_confirmed" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%;"></i>Confirmed Orders</a></li>
   		
   </ul>
</div>