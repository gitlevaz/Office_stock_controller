<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Substore_create" class="btn btn-link addnewButton"><i class="fa fa-shopping-bag" aria-hidden="true" style="margin-right:2%"></i>New Sub store</a></li>
   		<li><a href="<?php ROOT?>Substore_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Sub store</a></li>
   </ul>
</div>