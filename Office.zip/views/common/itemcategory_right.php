<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Itemcategory_category" class="btn btn-link addnewButton"><i class="fa fa-medkit" aria-hidden="true" style="margin-right:2%"></i>New Category</a></li>
   		<li><a href="<?php ROOT?>Itemcategory_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Category</a></li>
   </ul>
</div>