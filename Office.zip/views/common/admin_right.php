<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Admin_users_home" class="btn btn-link addnewButton"><i class="fa fa-user" aria-hidden="true" style="margin-right:2%"></i>Users</a></li>
   		<li><a href="<?php ROOT?>Admin_privileges_home" class="btn btn-link addnewButton"><i class="fa fa-key" aria-hidden="true" style="margin-right:2%"></i>User Privileges</a></li>
   </ul>
</div>