<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Prescription_view" class="btn btn-link addnewButton"><i class="fa fa-newspaper-o" aria-hidden="true" style="margin-right:2%; transform: rotate(90deg);"></i>View Prescription</a></li>
   		<li><a href="<?php ROOT?>Prescription_Changestatus" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%;"></i>Edit Status</a></li>
   		<li><a href="<?php ROOT?>Prescription_home" class="btn btn-link addnewButton"><i class="" aria-hidden="true" style="margin-right:2%;"></i>Add Prescription</a></li>
   </ul>
</div>