<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Stockitmes_home" class="btn btn-link addnewButton"><i class="fa fa-archive aria-hidden=" true"="" style="margin-right:2%"></i>New Item</a></li>
   		<li><a href="<?php ROOT?>Stockitmes_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Item</a></li>
   </ul>
</div>