<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Grn_home" class="btn btn-link addnewButton"><i class="fa fa-file-text-o" aria-hidden="true" style="margin-right:2%"></i>New Grn</a></li>
   		<li><a href="<?php ROOT?>Grn_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Grn</a></li>
   </ul>
</div>