<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Itemcategory_subcategory" class="btn btn-link addnewButton"><i class="fa fa-suitcase" aria-hidden="true" style="margin-right:2%"></i>New SubCategory</a></li>
   		<li><a href="<?php ROOT?>Itemcategory_subcategoryedit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit Category</a></li>
   </ul>
</div>