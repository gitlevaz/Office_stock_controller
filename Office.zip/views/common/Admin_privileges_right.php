<div>
   <ul class="ulHope">
   		<li><a class="btn btn-link addnewButton" href="<?php ROOT?>Admin_privileges_home"><i class="fa fa-user-plus" aria-hidden="true" style="margin-right:1%"></i>New profile</a></li>
   		<!-- <li><a href="<?php ROOT?>Admin_privileges_set">Create Rools</a></li> -->
   </ul>
</div>