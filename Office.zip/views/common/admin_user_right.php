<div>
   <ul class="ulHope">
   		<li><a href="<?php ROOT?>Admin_users_home" class="btn btn-link addnewButton"><i class="fa fa-user-plus" aria-hidden="true" style="margin-right:1%"></i>Create New User</a></li>
   		<li><a href="<?php ROOT?>Admin_users_edit" class="btn btn-link addnewButton"><i class="fa fa-pencil" aria-hidden="true" style="margin-right:2%"></i>Edit User</a></li>
   </ul>
</div>