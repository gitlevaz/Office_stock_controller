<div class="col-sm-4 col-md-4">
	<input type="text" placeholder="keyword" class="search_key"> <label><div id="msg_box"></div></label>
	<button class="show_all">Show All</button>	
	<button class="print_all">Print</button><span class="glyphicon glyphicon-print" aria-hidden="true"></span>
</div>
<div class="col-sm-4 col-md-4">
</div>
<div class="col-sm-4 col-md-4">
	
</div>
