<div class="row">
	<div class="col-sm-2 col-md-2">
	<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Admin_privileges_home" class="backButton">Back</a></div></div>
		<?php
		//include 'views/common/Admin_privileges_right.php';
		?>	
	</div>
	<div class="col-sm-10 col-md-10">
	<div class="panel panel-info">
	  <div class="panel-heading"><h1>Access controler</h1></div>
	  <div class="panel-body">
		<div class="row">
		<input type="hidden" value="<?php echo $_GET['id'];?>" id="hidden_val1">
				<div id="cont"></div>
		</div>
		</div>
		</div>
	</div>
</div>
