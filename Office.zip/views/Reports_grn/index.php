<div class="row">
	<div class="col-sm-2 col-md-2">
		<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Reports_home" class="backButton">Back</a></div></div>
		<?php
		//include 'views/common/Inventory_home.php';
		?>	
	</div>
	<div class="col-sm-10 col-md-10">
	    <div class="panel panel-info">
		  <div class="panel-heading"><h1>Grns</h1></div>
		   <div class="panel-body">
				<div class="row search_types">
					<?php
						include 'views/common/reports_head_leveltwo.php';
					?>
				</div>
				<div class="row pagin" id="report"> 

				</div>
		   </div>
		</div>
	</div>
</div>
