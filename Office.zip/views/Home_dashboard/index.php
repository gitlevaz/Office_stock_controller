<title>HOPE Inventory Management</title>
<div class="container">
  <div class="row" style="padding-top:40px;">
    <div class="col-sm-3 col-md-3">
      <div class=""> <a href="<?php ROOT?>Admin_home" class="btn btn-link mainTab moduleBg"><i class="fa fa-star" aria-hidden="true" style="margin-right:2%"></i>Admin</a> </div>
    </div>
    <div class="col-sm-3 col-md-3">
      <div class=""> <a href="<?php ROOT?>Inventory_home" class="btn btn-link mainTab moduleBg"><i class="fa fa-folder-open" aria-hidden="true" style="margin-right:2%"></i>Inventory</a> </div>
    </div>
    <!-- <div class="col-sm-3 col-md-3">
      <div class=""> <a href="<?php ROOT?>" class="btn btn-link mainTab moduleBg"><i class="fa fa-money" aria-hidden="true" style="margin-right:2%"></i>Finance</a> </div>
    </div> -->
    <div class="col-sm-3 col-md-3">
      <div class=""> <a href="<?php ROOT?>PayHome" class="btn btn-link mainTab moduleBg"><i class="fa fa-credit-card-alt" aria-hidden="true" style="margin-right:2%;font-size: 1.3em !Important;"></i>Payroll</a> </div>
    </div>
  </div>
</div>
