<div class="row">
	<div class="col-sm-2 col-md-2">
		<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Home_dashboard" class="backButton"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div></div>
		<?php
		//include 'views/common/Inventory_home.php';
		?>	
	</div>
	<div class="col-sm-10 col-md-10">
		<div class="row">
			<ul class="center_menu center_Inventory_home">
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Customers_home"><i class="fa fa-user" aria-hidden="true" style="margin-right:2%"></i>Customer</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Supplier_home"><i class="fa fa-shopping-cart" aria-hidden="true" style="margin-right:2%"></i>Supplier</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Store_home"><i class="fa fa-database" aria-hidden="true" style="margin-right:2%"></i>Store</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Pos_home"><i class="fa fa-line-chart" aria-hidden="true" style="margin-right:2%"></i>Sells</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Substore_home"> <i class="fa fa-shopping-bag" aria-hidden="true" style="margin-right:2%"></i>Sub Store</a></li>
				<li class="thumbnail moduleBg"><a href="<?php ROOT?>Reports_home"><i class="fa fa-file-text" aria-hidden="true" style="margin-right:2%"></i>Reports</a></li>
			</ul>
		</div>
	</div>
</div>
