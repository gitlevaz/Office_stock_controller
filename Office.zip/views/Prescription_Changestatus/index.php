<div class="row">
<div class="col-sm-2 col-md-2">
	<div class="row"><div class="col-sm-12 col-md-12"><a href="<?php ROOT?>Pos_home" class="backButton"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="margin-right:2%"></i>Back</a></div></div>
	<?php
	include 'views/common/prescriptionstatus_right.php';
	?>	
</div>
<div class="col-sm-10 col-md-10">
	<div class="panel panel-info">
	  <div class="panel-heading"><h1><i class="fa fa-newspaper-o" aria-hidden="true" style="margin-right:0.5%; transform: rotate(90deg);"></i>Edit Status</h1></div>
	  <div class="panel-body">
	  <div id="msg_box"></div>
	</div>
	</div>

<div class="panel panel-default">
  <div class="panel-body">
<!--     <div class="table-responsive" id="grncontent"> -->
	 <div class="recent_prescription pagin">
	 </div>
<!-- 	</div> -->
<!-- 	<div class="row pagin" id="report"> 

	</div> -->
  </div>

</div>
</div>
</div>
<script type="text/javascript">
</script>