
<script type="text/javascript">
  $(document).ready(function() {
    $('.carousel').carousel({
      interval: 1500
    })
  });
</script>