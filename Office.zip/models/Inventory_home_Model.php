
<?php
class Inventory_home_Model extends model
{
	
	function __construct()
	{
		Session::init();
		parent::__construct();
	}

}
