
<?php
class PayHome_Model extends model
{
	
	function __construct()
	{
		Session::init();
		parent::__construct();
	}

}
