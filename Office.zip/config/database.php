<?php
define('DB_TYPE','mysql');

define('DB_HOST','localhost');
define('DB_NAME','db754992598');
define('DB_USER','root');
define('DB_PASS','');
///////////
// define('DB_HOST','fadnacart.db.11557681.hostedresource.com');
// define('DB_NAME','fadnacart');
// define('DB_USER','fadnacart');
// define('DB_PASS','Fadna2015!');