<?php
/*encryption key*/
define('EN_KEY', 'galaxynova');
/*website root path*/
//define("ROOT","http://inventory.lookuplands.com/");
//define("ROOT","http://dpmc.lookuplands.com/");
//define("ROOT","http://medical_center.com/");
//define("ROOT","localhost/medical_center/");
define('ROOT','http://localhost/Office/');
// define("ROOT","http://http://inventoryworks.ml/");
/*redirect to when invalid login*/
//define("REDIRECT","http://www.holidayquotation.com/");
// guesttoken
define("GUESTTOKEN",'poseidon');
//admin user
define("ADMINUSER",'admin');
//admin pass
define("ADMINPASS",'3M5YqQejacVsLdqqy974g/IGsU6ir2xeT7KilRNME7Q=');
//hide hedder and footer
//ex$pages="paymentView_page2_page3";
// $config['time_reference'] = 'local';

// $config['log_date_format'] = 'Y-m-d H:i:s';

$pages="Invoice_print";
define("NATIVE",$pages);